package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.dao.ConsumerDAO;
import com.cg.ebill.dao.ConsumerDAOImpl;
import com.cg.ebill.dto.Bill;
import com.cg.ebill.exception.EbillException;

public class ConsumerServiceImpl implements ConsumerService {
	ConsumerDAO dao=new ConsumerDAOImpl();
	@Override
	public List<Bill> searchBill(int ID) throws EbillException{
		return dao.searchBill(ID);
	}
	@Override
	public void insertBill(Bill bill) throws EbillException{
		dao.insertBill(bill);
	}

}
