package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebill.dto.Consumer;
import com.cg.ebill.exception.EbillException;
import com.cg.ebill.utility.DBConnection;

public class EbillDAOImpl implements EbillDAO{

	@Override
	public List<Consumer> getConsumerList() throws EbillException{
		List<Consumer> list=new ArrayList<>();
		Connection connection=DBConnection.getConnection();
		try(
			Statement statement=connection.createStatement();){
			ResultSet resultSet=statement.executeQuery("select * from Consumers");
			while(resultSet.next()){
				Consumer obj=new Consumer();
				obj.setConsumerNum(resultSet.getInt(1));
				obj.setConsumerName(resultSet.getString(2));
				obj.setConsumerAddress(resultSet.getString(3));
				list.add(obj);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EbillException("Error occured while fetching data..");
		}
		return list;
	}
	@Override
	public List<Consumer> searchConsumer(int ID) throws EbillException {
		List<Consumer> list1=new ArrayList<>();
		System.out.println(ID);
		Connection connection=DBConnection.getConnection();
		try(
				Statement statement=connection.createStatement();){
				ResultSet resultSet=statement.executeQuery("select * from Consumers where consumer_num = "+ID);
				while(resultSet.next()){	
				Consumer obj=new Consumer();
					obj.setConsumerNum(resultSet.getInt(1));
					obj.setConsumerName(resultSet.getString(2));
					obj.setConsumerAddress(resultSet.getString(3));
					list1.add(obj);
				}
		} catch (SQLException e) {
		throw new EbillException("Error occured while fetching data..");
		}
		return list1;
	}
}
