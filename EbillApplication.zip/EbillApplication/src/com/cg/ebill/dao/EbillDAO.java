package com.cg.ebill.dao;

import java.util.List;

import com.cg.ebill.dto.Consumer;
import com.cg.ebill.exception.EbillException;

public interface EbillDAO {

	public abstract List<Consumer> getConsumerList() throws EbillException;
	public abstract List<Consumer> searchConsumer(int ID) throws EbillException;

}