package com.cg.ebill.dao;

import java.util.List;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.exception.EbillException;

public interface ConsumerDAO {

	public abstract List<Bill> searchBill(int ID) throws EbillException;
	public abstract void insertBill(Bill bill) throws EbillException;

}