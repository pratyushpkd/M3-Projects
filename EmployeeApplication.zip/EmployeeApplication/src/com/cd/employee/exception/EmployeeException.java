package com.cd.employee.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 206774198889877909L;

	public EmployeeException() {
		super();
		
	}

	public EmployeeException(String arg0) {
		super(arg0);
		
	}
	
	

}
