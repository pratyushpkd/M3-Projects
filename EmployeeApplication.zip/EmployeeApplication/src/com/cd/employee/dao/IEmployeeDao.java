package com.cd.employee.dao;

import java.util.List;

import com.cd.employee.bean.EmployeeBean;
import com.cd.employee.exception.EmployeeException;

public interface IEmployeeDao {
	public int insertEmployee(EmployeeBean employeeBean)throws EmployeeException;
	
	public EmployeeBean getEmployee(int empid)throws EmployeeException;
	
	public List<EmployeeBean> getAllEmployee()throws EmployeeException;
	
	public boolean deleteEmployee(int empid)throws EmployeeException;

}
