package com.cd.employee.dao;

public interface IQuerryMapperDao {
	public static final String INSERT_EMPLOYEE="INSERT INTO employ VALUES(?,?,?,?,?)";
	public static final String VIEWALL_EMPLOYEE="SELECT * FROM employ";
	public static final String VIEW_EMPLOYEE="SELECT * FROM employ WHERE empid=?";
	public static final String DELETE_EMPLOYEE="DELETE FROM employ WHERE empid=?";

}
