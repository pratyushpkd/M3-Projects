package com.cd.employee.service;

import java.util.List;

import com.cd.employee.bean.EmployeeBean;
import com.cd.employee.dao.EmployeeDaoImpl;
import com.cd.employee.dao.IEmployeeDao;
import com.cd.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	private IEmployeeDao employeeDao = new EmployeeDaoImpl();
	
	@Override
	public int insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		
		return employeeDao.insertEmployee(employeeBean);
	}

	@Override
	public EmployeeBean getEmployee(int empid) throws EmployeeException {
		
		return employeeDao.getEmployee(empid);
	}

	@Override
	public List<EmployeeBean> getAllEmployee() throws EmployeeException {
		
		return employeeDao.getAllEmployee();
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException {
		
		return employeeDao.deleteEmployee(empid);
	}

}
