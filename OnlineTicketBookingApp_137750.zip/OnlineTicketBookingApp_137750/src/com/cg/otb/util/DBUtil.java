package com.cg.otb.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {

	private static Connection connection  = null;
	
	public static Connection getConnection()
	{
		InitialContext ctx = null;
		DataSource dataSource = null;
		
		try {
			ctx = new InitialContext();
			dataSource=(DataSource) ctx.lookup("java:/CapgeminiDS");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			connection  = dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
		
		
		
		
	}
}
