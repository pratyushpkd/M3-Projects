
package com.cg.otb.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otb.dto.ShowDetails;
import com.cg.otb.exception.ShowException;
import com.cg.otb.service.IShowService;
import com.cg.otb.service.ShowServiceImpl;

@WebServlet(urlPatterns={"/listAllShows","/getShowDetails","/BookTicket"})
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IShowService showService ;
    public ShowController() 
    {
        super();
        showService = new ShowServiceImpl();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String path = request.getServletPath() ;
		String url="" ;
		
		try
		{
		switch (path) 
		{
			
			case "/listAllShows":
				System.out.println("Hello");
				List<ShowDetails> showList = showService.getShowDetails();
				
				HttpSession session = request.getSession();
				session.setAttribute("showList", showList);
				url="showDetails.jsp";
				break;
				
			
			case "/getShowDetails" :
				System.out.println("Getting Show Details");
				String showid = request.getParameter("showid") ;
				System.out.println(showid);
				ShowDetails show = showService.getShowDetail(showid);
				System.out.println(show);
				request.setAttribute("show", show);
				url="bookNow.jsp";
				break;
				
			
			case "/BookTicket":
				String showName = request.getParameter("txtShowName");
				double price = Double.parseDouble(request.getParameter("txtPrice")) ;
				String customerName = request.getParameter("txtCustName");
				long mob =Long.parseLong(request.getParameter("txtMobNo"));
				int availSeats = Integer.parseInt(request.getParameter("txtSeatsAvail"));
				int noOfSeats = Integer.parseInt(request.getParameter("txtSeatsBook"));
				
				if(noOfSeats == 0 || noOfSeats < 0)
				{
					throw new ShowException("Please enter number of seats available");
				}
				
				if(availSeats < noOfSeats)
				{
					throw new ShowException("Please enter number of seats available");
				}
				else
				{
					int updatedSeats = availSeats-noOfSeats ;
					request.setAttribute("showname", showName);
					request.setAttribute("cname", customerName);
					request.setAttribute("mobileNo", mob);
					request.setAttribute("noOfSeats", noOfSeats);
					double totalPrice = price * noOfSeats ;
					request.setAttribute("totalPrice", totalPrice);
					showService.updateShowDetails(updatedSeats , showName);
					url = "success.jsp" ;
				}
				
				break ;

		default:
			break;
		}
		}
		catch(ShowException e)
		{
			request.setAttribute("error", e.getMessage());
			url = "error.jsp" ;
		}
		catch (Exception e) 
		{
			request.setAttribute("error", e.getMessage());
			url = "error.jsp" ;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}

}
