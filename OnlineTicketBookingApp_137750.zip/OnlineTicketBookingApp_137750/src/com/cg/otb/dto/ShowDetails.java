package com.cg.otb.dto;

import java.sql.Date;

public class ShowDetails {
	
	private String showid;
	private String showname;
	private String location;
	private Date showdate ;
	private int avseats ;
	private double priceTicket ;
	public ShowDetails() {
		super();
	}
	public ShowDetails(String showid, String showname, String location,
			Date showdate, int avseats, double priceTicket) {
		super();
		this.showid = showid;
		this.showname = showname;
		this.location = location;
		this.showdate = showdate;
		this.avseats = avseats;
		this.priceTicket = priceTicket;
	}
	public String getShowid() {
		return showid;
	}
	public void setShowid(String showid) {
		this.showid = showid;
	}
	public String getShowname() {
		return showname;
	}
	public void setShowname(String showname) {
		this.showname = showname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getShowdate() {
		return showdate;
	}
	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}
	public int getAvseats() {
		return avseats;
	}
	public void setAvseats(int avseats) {
		this.avseats = avseats;
	}
	public double getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}
	
	@Override
	public String toString() {
		return "ShowDetails [showId=" + showid + ", showName=" + showname
				+ ", location=" + location + ", showDate=" + showdate
				+ ", availableSeats=" + avseats + ", price=" + priceTicket
				+ "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((showid == null) ? 0 : showid.hashCode());
		return result;
	}

}
