package com.cg.otb.dao;

import java.util.List;

import com.cg.otb.dto.ShowDetails;
import com.cg.otb.exception.ShowException;

public interface IShowDAO 
{
	List<ShowDetails> getShowDetails() throws ShowException ;
	public ShowDetails getShowDetail(String showid) throws ShowException ;
	public void updateShowDetails(int seats , String showname) throws ShowException ;
}
