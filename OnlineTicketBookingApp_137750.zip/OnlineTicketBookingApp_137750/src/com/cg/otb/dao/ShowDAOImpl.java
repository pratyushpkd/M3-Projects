
package com.cg.otb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.otb.constants.AllConstants;
import com.cg.otb.dto.ShowDetails;
import com.cg.otb.exception.ShowException;
import com.cg.otb.util.DBUtil;

public class ShowDAOImpl implements IShowDAO {
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet resultSet;

	@Override
	public List<ShowDetails> getShowDetails() throws ShowException {
		List<ShowDetails> showDetailsList = new ArrayList<ShowDetails>();
		try {
			conn = DBUtil.getConnection();
			stmt = conn.createStatement();
			resultSet = stmt.executeQuery(AllConstants.showDetailsCommand);
			while (resultSet.next()) {
				ShowDetails show = new ShowDetails();
				show.setShowid(resultSet.getString(1));
				show.setShowname(resultSet.getString(2));
				show.setLocation(resultSet.getString(3));
				show.setShowdate(resultSet.getDate(4));
				show.setAvseats(resultSet.getInt(5));
				show.setPriceTicket(resultSet.getDouble(6));
				showDetailsList.add(show);
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new ShowException("Something went wrong while fetching showDetails");
		} finally {
			try {
				resultSet.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				throw new ShowException("SQLException occurred");
			}
		}
		return showDetailsList;
	}

	@Override
	public ShowDetails getShowDetail(String showid) throws ShowException {
		ShowDetails show = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(AllConstants.getShowDetailCommand);
			pstmt.setString(1, showid);
			resultSet = pstmt.executeQuery();
			resultSet.next();
			show = new ShowDetails();
			show.setShowid(resultSet.getString(1));
			show.setShowname(resultSet.getString(2));
			show.setLocation(resultSet.getString(3));
			show.setShowdate(resultSet.getDate(4));
			show.setAvseats(resultSet.getInt(5));
			show.setPriceTicket(resultSet.getDouble(6));

		} catch (SQLException e) {
			// e.printStackTrace();
			throw new ShowException("Problem while fetching show details");
		} finally {
			try {
				resultSet.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				throw new ShowException("SQLException occurred");
			}

		}
		return show;
	}

	@Override
	public void updateShowDetails(int seats, String showname) throws ShowException {
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(AllConstants.updateShowCommand);
			pstmt.setInt(1, seats);
			pstmt.setString(2, showname);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new ShowException("Problem while updating the table");
		}
	}

}
