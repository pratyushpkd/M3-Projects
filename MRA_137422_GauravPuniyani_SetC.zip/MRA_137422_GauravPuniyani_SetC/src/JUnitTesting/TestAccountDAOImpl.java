package JUnitTesting;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.service.IAccountService;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: JUnit Testing 
	 */

	
//=================================================================================================================


public class TestAccountDAOImpl {

	static IAccountService accountService;
	
	@BeforeClass
	public static void init(){
		accountService = new AccountServiceImpl();
	}
	
	@AfterClass
	public static void destroy(){
		accountService = null;
		System.gc();
	}
	
	
	@Test
	public void testGetAccountDetails() {
		Account account = new Account("Pre Paid", "TestName", 111);
		
		String accountid = "105";
		
		try 
		{
			account = accountService.getAccountDetails(accountid);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

	
	@Test(expected = AccountException.class)
	public void testRemoveEmployee() throws AccountException 
	{
			accountService.getAccountDetails("414141");
		
	}

}
