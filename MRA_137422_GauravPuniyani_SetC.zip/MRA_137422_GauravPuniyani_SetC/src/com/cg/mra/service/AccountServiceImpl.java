package com.cg.mra.service;

import com.cg.mra.dao.AccountDAOImpl;
import com.cg.mra.dao.IAccountDAO;
import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Acccount Service Implementation
	 */

	
//=================================================================================================================


public class AccountServiceImpl implements IAccountService {
	
	IAccountDAO accountDAO;

	public AccountServiceImpl() {
		
		accountDAO = new AccountDAOImpl();
	}
	
//=======================================================================================

	@Override
	public Account getAccountDetails(String accountId) throws AccountException {
		
		return accountDAO.getAccountDetails(accountId);
	}
	
//=======================================================================================

	@Override
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException {
		
		return accountDAO.rechargeAccount(accountId, rechargeAmount);
				
	}

	

}
