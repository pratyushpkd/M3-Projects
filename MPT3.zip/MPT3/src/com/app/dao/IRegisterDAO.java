package com.app.dao;

import com.app.dto.FirmMaster;
//DAO interface for methods
public interface IRegisterDAO {
public boolean addRecord(FirmMaster firm);
public boolean updateRecord(String email);
}
