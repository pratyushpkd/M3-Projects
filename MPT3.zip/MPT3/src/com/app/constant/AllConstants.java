package com.app.constant;

//Database Schema
/*Name          Null?    Type          
------------- -------- ------------- 
FIRM_ID       NOT NULL NUMBER(8)     
OWNER_NAME             VARCHAR2(100) 
BUSINESS_NAME          VARCHAR2(100) 
EMAIL                  VARCHAR2(80)  
MOBILE_NO              VARCHAR2(10)  
ISACTIVE               CHAR(1)       */
public class AllConstants {
//Queries for the database
public static final String insert="INSERT INTO firms_master values(seq_firm_master.nextval,?,?,?,?,?)";
public static final String update="UPDATE firms_master SET isactive='Y' where email=?";
public static final String search="SELECT seq_firm_master.currval FROM DUAL";
}
