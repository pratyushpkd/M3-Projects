package com.cg.banking.bean;

public class BankingBean {

	
	private String account_number;
	private String customer_name; 
	private String account_type; 
	private String account_location; 
	private float balance;
	public BankingBean() {
		super();
	}
	public BankingBean(String account_number, String customer_name,
			String account_type, String account_location, float balance) {
		super();
		this.account_number = account_number;
		this.customer_name = customer_name;
		this.account_type = account_type;
		this.account_location = account_location;
		this.balance = balance;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getAccount_location() {
		return account_location;
	}
	public void setAccount_location(String account_location) {
		this.account_location = account_location;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankingBean [account_number=" + account_number
				+ ", customer_name=" + customer_name + ", account_type="
				+ account_type + ", account_location=" + account_location
				+ ", balance=" + balance + "]";
	}
	
	

	
}
