package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.dto.Customer;
import com.capgemini.dto.DVD;
import com.capgemini.exception.DVDException;

public interface IDVDDAO {
	
	/***Methods which we have to implement in DAO class******/
	
	public ArrayList<DVD> getAllDVD() throws DVDException;

	public void addCustomerDetails(Customer customer) throws DVDException;

	public Customer getCustomerDetails(String UserName) throws DVDException;
}
