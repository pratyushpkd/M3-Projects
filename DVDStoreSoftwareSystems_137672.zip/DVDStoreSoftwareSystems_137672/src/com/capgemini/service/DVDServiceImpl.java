package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.dao.DVDDAOImpl;
import com.capgemini.dao.IDVDDAO;
import com.capgemini.dto.Customer;
import com.capgemini.dto.DVD;
import com.capgemini.exception.DVDException;

public class DVDServiceImpl implements IDVDService {

	
	/*
	 * Association Of Classes
	 * 
	 */
	
	IDVDDAO idvdDao;

	public DVDServiceImpl() {
		idvdDao = new DVDDAOImpl();
	}

	@Override
	public ArrayList<DVD> getAllDVD() throws DVDException {
		return idvdDao.getAllDVD();
	}

	@Override
	public void addCustomerDetails(Customer customer) throws DVDException {
		idvdDao.addCustomerDetails(customer);
	}

	@Override
	public Customer getCustomerDetails(String UserName) throws DVDException {
		return idvdDao.getCustomerDetails(UserName);
	}

}
