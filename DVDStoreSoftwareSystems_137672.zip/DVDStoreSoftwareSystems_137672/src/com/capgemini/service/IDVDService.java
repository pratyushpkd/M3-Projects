package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.dto.Customer;
import com.capgemini.dto.DVD;
import com.capgemini.exception.DVDException;

public interface IDVDService {
	
	/***Methods which we have to implement in service class******/
	
	public ArrayList<DVD> getAllDVD() throws DVDException;

	public void addCustomerDetails(Customer customer) throws DVDException;

	public Customer getCustomerDetails(String UserName) throws DVDException;
}
