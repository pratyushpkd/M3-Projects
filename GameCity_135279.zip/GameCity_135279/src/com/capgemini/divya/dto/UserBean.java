package com.capgemini.divya.dto;

public class UserBean {
	private int userId;
	private String userName;
	private String address;
	private int cardAmt;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getCardAmt() {
		return cardAmt;
	}

	public void setCardAmt(int cardAmt) {
		this.cardAmt = cardAmt;
	}

	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", userName=" + userName
				+ ", address=" + address + ", cardAmt=" + cardAmt + "]";
	}

	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserBean(int userId, String userName, String address, int cardAmt) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.address = address;
		this.cardAmt = cardAmt;
	}

}
