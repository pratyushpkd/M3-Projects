drop table cricket_score;

CREATE TABLE cricket_score(
	player_id NUMBER PRIMARY KEY,
	player_name VARCHAR2(40),
	dob DATE, 
	country  VARCHAR2(40),
	batting_style VARCHAR2(20),
	centuries NUMBER,
	matches NUMBER, 
	total_run_score NUMBER
);

drop sequence player_seq;

CREATE SEQUENCE player_seq; 

  INSERT INTO cricket_score VALUES(player_seq.NEXTVAL,'Sachin Tendulkar','24-APR-1973','India','Right Handed Batsman',49,463,18426);
  INSERT INTO cricket_score VALUES(player_seq.NEXTVAL,'R.T Ponting','19-DEC-1974','Australia','Left Handed Batsman',30,375,13704);
  INSERT INTO cricket_score VALUES(player_seq.NEXTVAL,'S.T Jayasuriya','30-JUN-1969','Shrilanka','Right Handed Batsman',28,445,13480);
  INSERT INTO cricket_score VALUES(player_seq.NEXTVAL,'S.C Ganguly','8-JUL-1972','India','Left Handed Batsman',22,311,11363);
