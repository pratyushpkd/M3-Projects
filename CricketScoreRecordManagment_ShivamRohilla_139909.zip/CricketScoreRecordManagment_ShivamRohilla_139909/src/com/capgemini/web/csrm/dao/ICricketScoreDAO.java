package com.capgemini.web.csrm.dao;

import java.util.List;

import com.capgemini.web.csrm.dto.PlayerBean;
import com.capgemini.web.csrm.exception.CricketScoreException;

public interface ICricketScoreDAO {
	/**
	 * @param playerBean
	 * @return int
	 * @throws CricketScoreException
	 */
	public int addPlayer(PlayerBean playerBean) throws CricketScoreException;
	/**
	 * @return List
	 * @throws CricketScoreException
	 */
	public List<PlayerBean> viewAllPlayers() throws CricketScoreException;
}
