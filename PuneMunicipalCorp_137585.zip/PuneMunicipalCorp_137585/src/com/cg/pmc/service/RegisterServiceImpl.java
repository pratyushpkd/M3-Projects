package com.cg.pmc.service;

import com.cg.pmc.bean.FirmMaster;
import com.cg.pmc.dao.IRegisterDAO;
import com.cg.pmc.dao.RegisterDAOImpl;
import com.cg.pmc.exception.FirmException;

public class RegisterServiceImpl implements IRegisterService {

	IRegisterDAO registerDAO;
	public RegisterServiceImpl() {
		registerDAO=new RegisterDAOImpl();
	}

	@Override
	public int registerFirm(FirmMaster f) throws FirmException {
	
		return registerDAO.registerFirm(f);
	}

}
