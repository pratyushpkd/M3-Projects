package com.cg.pmc.bean;

public class FirmMaster {

	public FirmMaster() {
		
	}

	private int id;
	private String ownerName;
	private String businessName;
	private String email;
	private String mobileNo;
	private String isActive;
	public FirmMaster(String ownerName, String businessName, String email,
			String mobileNo) {
		super();
		this.ownerName = ownerName;
		this.businessName = businessName;
		this.email = email;
		this.mobileNo = mobileNo;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "FirmMaster [id=" + id + ", ownerName=" + ownerName
				+ ", businessName=" + businessName + ", email=" + email
				+ ", mobileNo=" + mobileNo + ", isActive=" + isActive + "]";
	}

	
	public FirmMaster(String ownerName, String businessName, String email,
			String mobileNo, String isActive) {
		super();
		this.ownerName = ownerName;
		this.businessName = businessName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.isActive = isActive;
	}
	public FirmMaster(int id, String ownerName, String businessName,
			String email, String mobileNo, String isActive) {
		super();
		this.id = id;
		this.ownerName = ownerName;
		this.businessName = businessName;
		this.email = email;
		this.mobileNo = mobileNo;
		this.isActive = isActive;
	}
}
