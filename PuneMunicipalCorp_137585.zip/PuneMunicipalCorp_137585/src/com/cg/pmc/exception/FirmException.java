package com.cg.pmc.exception;

public class FirmException extends Exception{

	public FirmException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FirmException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FirmException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FirmException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FirmException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	

}
